const rp = require('request-promise');
const requestOptions = {
method: 'GET',
  uri: 'https://api.coingecko.com/api/v3/coins/shiba-inu?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false&sparkline=false',
  qs: {
    
  },
  headers: {
    
  },
  json: true,
  gzip: true
};


rp(requestOptions).then(response => {

  
let string = JSON.stringify(response);
var shib = JSON.parse(string);
var price = shib['market_data']['current_price']['usd'];
console.log(price);
//client.user.setPresence({
//status: 'online',
//activity: {
//name: '$' + String(price).slice(0,10),
//type: "WATCHING"
//    }
//});
}).catch((err) => {
  console.log('API call error:', err.message);
});