const Discord = require('discord.js');

const client = new Discord.Client();

client.once('ready', () => {
    console.log('Raven A Mattie');
    setInterval(function(){
   const rp = require('request-promise');
   const requestOptions = {
  method: 'GET',
  uri: 'https://pro-api.coinmarketcap.com/v1/cryptocurrency/quotes/latest',
  qs: {
    'symbol': 'RVN'
  },
  headers: {
    'X-CMC_PRO_API_KEY': ''
  },
  json: true,
  gzip: true
};


rp(requestOptions).then(response => {
  let string = JSON.stringify(response);
   var shib = JSON.parse(string);
   var price = shib['data']['RVN']['quote']['USD']['price'];
   
 client.user.setPresence({
  status: 'online',
  activity: {
  name: '$' + String(price).slice(0,10),
  type: "WATCHING"
    }
});
}).catch((err) => {
  console.log('API call error:', err.message);
});


  }, 300000);
}); 





client.login('');